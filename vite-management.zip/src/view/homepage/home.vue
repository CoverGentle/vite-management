<template>
  <div>
    首页
  </div>
</template>

<script setup lang='ts'>
import {onMounted, reactive, ref, toRefs} from 'vue'

</script>

<style lang='less' scoped>
  
</style>